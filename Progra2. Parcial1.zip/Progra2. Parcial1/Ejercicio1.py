a = float(input("Ingrese el valor del cateto a: "))
b = float(input("Ingrese el valor de cateto b: "))

hipotenusa = (a2 + b2)*0.5
print("El valor de la hipotenusa es:",hipotenusa)

