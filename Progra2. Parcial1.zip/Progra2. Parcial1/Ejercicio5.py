num = int(input("Ingrese un numero entero:"))

if num % 5 == 0: print(num,"es divisible por 5")
else: print(num,"no es divisible por 5")
