minutos = int(input("Ingrese la cantidad de minutos: "))

horas = minutos // 60
minutos_restantes = minutos % 60

print(minutos,"minutos equivalen a:",horas,"horas y",minutos_restantes,"minutos.")
